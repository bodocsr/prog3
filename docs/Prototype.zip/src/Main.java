import java.io.IOException;

/**
 * Main osztály.
 */
@SuppressWarnings("SpellCheckingInspection")
public class Main {
    /**
     * main függvény.
     * @param args
     */
    @SuppressWarnings("SpellCheckingInspection")
    public static void main(String[] args) throws IOException {
        Game game = new Game();
        game.run();
    }
}
