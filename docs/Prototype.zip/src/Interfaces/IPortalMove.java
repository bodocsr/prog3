package Interfaces;

/**
 * Interfész a teleportkapu-párokon keresztül mozgáshoz.
 */
@SuppressWarnings("SpellCheckingInspection")
public interface IPortalMove {
    boolean moveThroughPortal();
}
