package Interfaces;

import Playground.GameState;

public interface IGameState {
    void changeGameState(GameState state);
}
