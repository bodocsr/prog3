package Interfaces;

/**
 * Interfész a fúráshoz.
 */
@SuppressWarnings("SpellCheckingInspection")
public interface IDrill {
    boolean drill();
}
