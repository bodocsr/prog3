package Interfaces;

/**
 * Interfész a mozgáshoz.
 */
@SuppressWarnings("SpellCheckingInspection")
public interface IMove {
    void move();
}
