package Interfaces;

/**
 * Interfész a bányászáshoz.
 */
@SuppressWarnings("SpellCheckingInspection")
public interface IMine {
    boolean mine();
}
