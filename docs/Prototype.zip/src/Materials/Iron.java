package Materials;

/**
 * Vas osztály.
 * A Material leszármazottja.
 */
@SuppressWarnings("SpellCheckingInspection")
public class Iron extends Material {}
